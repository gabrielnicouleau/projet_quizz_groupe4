<?php
//Paramètrage de la BDD
const DB_HOST = "localhost";
const DB_NAME = "quizz";
const DB_USER = "root";
const DB_PASSWORD = "root";
//base URL
const BASE_URL = '/tpapi/';
//Temps de validitée du token JWT en minutes
const TOKEN_VALIDITY = 60;
//Clé de chiffrement du token JWT
const TOKEN_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4KYp9pzmDsrm0+wISY25
PCscXTgqexYkhwD2OZxArrRoDjiYgUUmrysM5QdiOb2NPodfKmfmi2p0T6boQ7wh
NHO306ISKxprCwgq4vnUM2riYv0rs6xa8kiHfIE6+XVah4BvgTv08Zk/z761SYcu
GRTuVc7Ai27w7oYJBWjnnqyK9VZstgx8KsFvrFE+Jnf1oIpATEhCgaAYK3fMp01k
rbpzXf8n5Ydoccd1rrQlTGS73nTcZvlpeX7AOmdWTcTsTyHANl5h4m+5tbwzikeV
M0gCAWE2LFpBNsaZ1s6UtESduUQyYToAtyrriH4RTx/fWfHmh+JwgOEYGlIVAyQI
5wIDAQAB";

?>